document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const registrationForm = document.getElementById('registration-form');
    const registrationSection = document.getElementById('registration-section');
    const videoSection = document.getElementById('video-section');
    const processingSection = document.getElementById('processing-section');
    const webcamElement = document.getElementById('webcam');
    const startCaptureBtn = document.getElementById('start-capture');
    const cancelCaptureBtn = document.getElementById('cancel-capture');
    const recordingProgress = document.getElementById('recording-progress');
    const recordingTimeElement = document.getElementById('recording-time');
    const processingProgressFill = document.querySelector('#processing-progress .progress-fill');
    const processingStepElement = document.getElementById('processing-step');
    const countdownElement = document.getElementById('countdown');
    
    // Global variables
    let stream = null;
    let mediaRecorder = null;
    let recordedChunks = [];
    let recordingInterval = null;
    let recordingTime = 0;
    let userId = null;
    
    // Handle registration form submission
    registrationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(registrationForm);
        
        // Submit form data to backend
        fetch('/register', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                userId = data.user_id;
                registrationSection.classList.add('hidden');
                videoSection.classList.remove('hidden');
                initWebcam();
            }
        })
        .catch(error => {
            console.error('Error during registration:', error);
            alert('An error occurred during registration. Please try again.');
        });
    });
    
    // Initialize webcam
    function initWebcam() {
        navigator.mediaDevices.getUserMedia({ video: true, audio: true })
            .then(function(mediaStream) {
                stream = mediaStream;
                webcamElement.srcObject = mediaStream;
                webcamElement.play();
            })
            .catch(function(error) {
                console.error('Error accessing webcam:', error);
                alert('Unable to access webcam. Please ensure you have given permission and try again.');
            });
    }
    
    // Start video capture
    startCaptureBtn.addEventListener('click', function() {
        if (!stream) {
            alert('Webcam is not initialized. Please reload the page and try again.');
            return;
        }
        
        // Show countdown before recording
        showCountdown(3, function() {
            startRecording();
        });
    });
    
    // Show countdown before recording
    function showCountdown(seconds, callback) {
        countdownElement.style.display = 'block';
        countdownElement.textContent = seconds;
        
        const interval = setInterval(function() {
            seconds--;
            countdownElement.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(interval);
                countdownElement.style.display = 'none';
                callback();
            }
        }, 1000);
    }
    
    // Start recording video
    function startRecording() {
        recordedChunks = [];
        
        // Set up media recorder
        mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
        
        mediaRecorder.ondataavailable = function(e) {
            if (e.data.size > 0) {
                recordedChunks.push(e.data);
            }
        };
        
        mediaRecorder.onstop = function() {
            // Stop the recording timer
            clearInterval(recordingInterval);
            
            // Hide video section and show processing section
            videoSection.classList.add('hidden');
            processingSection.classList.remove('hidden');
            
            // Create a blob from the recorded chunks
            const blob = new Blob(recordedChunks, { type: 'video/webm' });
            
            // Convert blob to base64 data URL
            const reader = new FileReader();
            reader.readAsDataURL(blob);
            
            reader.onloadend = function() {
                const base64data = reader.result;
                
                // Send video to server
                sendVideoToServer(base64data);
            };
        };
        
        // Start recording
        mediaRecorder.start(100);
        
        // Show recording progress
        recordingProgress.classList.remove('hidden');
        recordingTime = 0;
        
        // Update recording time every second
        recordingInterval = setInterval(function() {
            recordingTime++;
            recordingTimeElement.textContent = recordingTime;
            
            // Update progress bar
            const progressFill = document.querySelector('#recording-progress .progress-fill');
            progressFill.style.width = (recordingTime / 30 * 100) + '%';
            
            // Stop recording after 30 seconds
            if (recordingTime >= 30) {
                stopRecording();
            }
        }, 1000);
        
        // Disable start button and enable stop button
        startCaptureBtn.disabled = true;
    }
    
    // Stop recording
    function stopRecording() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    }
    
    // Cancel capture
    cancelCaptureBtn.addEventListener('click', function() {
        if (recordingInterval) {
            clearInterval(recordingInterval);
        }
        
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
        
        recordingProgress.classList.add('hidden');
        startCaptureBtn.disabled = false;
        
        // Stop webcam stream
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        
        // Go back to registration form
        videoSection.classList.add('hidden');
        registrationSection.classList.remove('hidden');
    });
    
    // Send video to server
    function sendVideoToServer(videoData) {
        // Show processing steps
        updateProcessingProgress(10, 'Uploading video...');
        
        fetch('/save_video', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                video_data: videoData,
                user_id: userId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Complete success - simulate processing steps
                simulateProcessingSteps();
            } else if (data.status === 'partial_success') {
                // Handle partial success (registration ok but model training failed)
                // Show a nicer message with more explanation
                const message = 'Your registration was completed successfully, but there was an issue with the face recognition training. ' +
                                'This may affect future recognition accuracy. You can continue with the registration or try again later.';
                
                if (confirm(message + '\n\nClick OK to continue or Cancel to try again.')) {
                    // User clicked OK - continue with registration
                    simulateProcessingSteps();
                } else {
                    // User clicked Cancel - go back to registration
                    processingSection.classList.add('hidden');
                    registrationSection.classList.remove('hidden');
                }
            } else {
                // Handle error
                alert('Error processing video: ' + data.message);
                // Go back to registration form
                processingSection.classList.add('hidden');
                registrationSection.classList.remove('hidden');
            }
        })
        .catch(error => {
            console.error('Error sending video:', error);
            alert('An error occurred while processing your video. Please try again.');
            // Go back to registration form
            processingSection.classList.add('hidden');
            registrationSection.classList.remove('hidden');
        });
    }
    
    // Update processing progress
    function updateProcessingProgress(percent, step) {
        processingProgressFill.style.width = percent + '%';
        processingStepElement.textContent = step;
    }
    
    // Simulate processing steps (for UI feedback)
    function simulateProcessingSteps() {
        setTimeout(() => {
            updateProcessingProgress(30, 'Extracting frames...');
            
            setTimeout(() => {
                updateProcessingProgress(50, 'Generating annotations...');
                
                setTimeout(() => {
                    updateProcessingProgress(70, 'Training model...');
                    
                    setTimeout(() => {
                        updateProcessingProgress(100, 'Completing registration...');
                        
                        // Redirect to confirmation page
                        setTimeout(() => {
                            window.location.href = '/confirmation/' + userId;
                        }, 1500);
                    }, 3000);
                }, 2000);
            }, 2000);
        }, 2000);
    }
});
