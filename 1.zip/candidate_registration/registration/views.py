from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import base64
import os
import time

from registration.utils.utils import save_user_data, create_required_directories, update_registration_status
from registration.utils.db import get_user, update_user, is_mongodb_available
from registration.utils.video_processor import process_video, extract_frames, store_frames_in_db
from registration.utils.model_trainer import train_yolo_model

create_required_directories()

def index(request):
    return render(request, 'index.html')

@csrf_exempt
def register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        education = request.POST.get('education')
        user_id = save_user_data(name, email, phone, education)
        return JsonResponse({'status': 'success', 'user_id': user_id})

@csrf_exempt
def save_video(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        video_data = data.get('video_data', '')
        user_id = data.get('user_id', '')

        if not video_data or not user_id:
            return JsonResponse({'status': 'error', 'message': 'Missing video data or user ID'})

        try:
            video_data = video_data.split(',')[1]
            user_dir = os.path.join('static', 'data', user_id)
            os.makedirs(user_dir, exist_ok=True)

            video_path = os.path.join(user_dir, 'video.webm')
            with open(video_path, 'wb') as f:
                f.write(base64.b64decode(video_data))

            if is_mongodb_available():
                update_user(user_id, {
                    "video_saved": True,
                    "video_saved_at": time.time(),
                    "registration_status": "video_captured"
                })

            frames_dir = os.path.join(user_dir, 'frames')
            os.makedirs(frames_dir, exist_ok=True)
            if not extract_frames(video_path, frames_dir):
                update_user(user_id, {"registration_status": "frame_extraction_failed"})
                return JsonResponse({'status': 'error', 'message': 'Failed to extract frames'})

            annotations_dir = os.path.join(user_dir, 'annotations')
            os.makedirs(annotations_dir, exist_ok=True)
            if not process_video(frames_dir, annotations_dir, user_id):
                update_user(user_id, {"registration_status": "annotation_generation_failed"})
                return JsonResponse({'status': 'error', 'message': 'Annotation generation failed'})

            store_frames_in_db(frames_dir, user_id)

            model_dir = os.path.join('static', 'models')
            os.makedirs(model_dir, exist_ok=True)
            update_user(user_id, {"registration_status": "model_training_started"})

            result = train_yolo_model(frames_dir, annotations_dir, model_dir, user_id)
            if not result:
                update_registration_status(user_id, True, "completed_without_model")
                return JsonResponse({'status': 'partial_success', 'message': 'Model training failed'})

            update_registration_status(user_id, True, "completed_successfully")
            return JsonResponse({'status': 'success', 'message': 'Model trained'})
        except Exception as e:
            if is_mongodb_available():
                update_user(user_id, {
                    "registration_status": "error",
                    "error_message": str(e),
                    "error_time": time.time()
                })
            return JsonResponse({'status': 'error', 'message': str(e)})

def confirmation(request, user_id):
    user_data = get_user(user_id)
    if not user_data:
        user_data = {
            'id': user_id,
            'name': 'Unknown',
            'email': 'unknown@example.com',
            'status': 'Unavailable'
        }
    return render(request, 'confirmation.html', {'user': user_data})
