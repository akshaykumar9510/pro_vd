from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register', views.register, name='register'),
    path('save_video', views.save_video, name='save_video'),
    path('confirmation/<str:user_id>', views.confirmation, name='confirmation'),
]
